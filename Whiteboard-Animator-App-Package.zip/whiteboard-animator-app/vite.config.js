import { defineConfig } from 'vite';
export default defineConfig({ base: './', root: 'www', build: { outDir: '../dist', emptyOutDir: true } });
